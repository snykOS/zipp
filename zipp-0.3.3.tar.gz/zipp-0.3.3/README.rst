.. image:: https://img.shields.io/pypi/v/zipp.svg
   :target: https://pypi.org/project/zipp

.. image:: https://img.shields.io/pypi/pyversions/zipp.svg

.. image:: https://img.shields.io/travis/jaraco/zipp/master.svg
   :target: https://travis-ci.org/jaraco/zipp

.. image:: https://img.shields.io/appveyor/ci/jaraco/zipp/master.svg
   :target: https://ci.appveyor.com/project/jaraco/zipp/branch/master

.. image:: https://readthedocs.org/projects/zipp/badge/?version=latest
   :target: https://zipp.readthedocs.io/en/latest/?badge=latest


A pathlib-compatible Zipfile object wrapper.
